class StochasticDepth(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torchvision.ops.stochastic_depth.___torch_mangle_90.StochasticDepth) -> NoneType:
    return None
